# AFL Live Scores Static MVP

Static version of the AFL scores app. No backend required.

## How it works
- Frontend fetches directly from the public Squiggle API
- Squiggle supports CORS (`Access-Control-Allow-Origin: *`)
- Safe to deploy to static hosting like Netlify, Vercel, Cloudflare Pages, GitHub Pages, or simple object storage

## Files
- `index.html`
- `app.js`
- `styles.css`

## Deploy anywhere
Upload the contents of this folder to any static host.

## Local preview
```bash
python3 -m http.server 8080
```
Then open <http://localhost:8080/afl-live-scores-static/>
